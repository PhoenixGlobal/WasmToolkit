#pragma once

struct locale_s {};
typedef struct locale_s* locale_t;
///typedef locale_s locale_t;
