#pragma once

typedef unsigned long size_t;
typedef long ptrdiff_t; //XXX intptr_t
